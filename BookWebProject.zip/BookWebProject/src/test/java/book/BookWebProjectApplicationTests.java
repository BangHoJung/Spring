package book;

import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class BookWebProjectApplicationTests {

	
}
